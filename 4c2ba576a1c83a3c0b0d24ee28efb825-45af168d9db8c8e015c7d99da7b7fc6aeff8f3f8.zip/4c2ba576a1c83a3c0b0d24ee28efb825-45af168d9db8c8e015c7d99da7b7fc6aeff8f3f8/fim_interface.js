require([
    'underscore',
    'jquery',
    'splunkjs/mvc',
    'splunkjs/mvc/simplexml/ready!'
], function (_, $, mvc) {
    var tokens = mvc.Components.get('submitted');

    /* --- Search Reference --- */
    var updateSearch = mvc.Components.get('updateExpectedHashSearch');
    var createSearch = mvc.Components.get('createAuditEntrySearch');
    var fimStatusSearch = mvc.Components.get('fimStatusSearch');
    var fimAuditSearch = mvc.Components.get('fimAuditSearch');

    var fimStatusTable = mvc.Components.get('fim_status');

    /* --- Reference to the input values --- */
    var host_Val, filename_Val, expected_Val, key_Val;

    fimStatusTable.on('click', function (e) {

        e.preventDefault();
        if (e['field'] === 'action') {
            /* --- Pull values from the current table row --- */
            host_Val = e.data['row.host'];
            filename_Val = e.data['row.filename'];
            expected_Val = e.data['row.current'];
            key_Val = e.data['row.key'];

            /* --- this is an update --- */
            e.preventDefault();
            tokens.set('update_key_tok', key_Val);
            tokens.set('update_host_tok', host_Val);
            tokens.set('update_filename_tok', filename_Val);
            tokens.set('update_expected_tok', expected_Val);

            console.log("Updating Hashtable...");
            console.log("Key:" + key_Val);
            console.log("Host:" + host_Val);
            console.log("Filename:" + filename_Val);
            console.log("Expected:" + expected_Val);

            /* --- this is a new create --- */
            tokens.set('create_tok', 'true');
            tokens.set('create_host_tok', host_Val);
            tokens.set('create_filename_tok', filename_Val);
            tokens.set('create_expected_tok', expected_Val);
        }

    });

    /* --- Search Jobs --- */
    updateSearch.on('search:done', function () {

        fimStatusSearch.startSearch();
        fimAuditSearch.startSearch();

    });

    createSearch.on('search:done', function () {

        fimStatusSearch.startSearch();
        fimAuditSearch.startSearch();
    });
});

