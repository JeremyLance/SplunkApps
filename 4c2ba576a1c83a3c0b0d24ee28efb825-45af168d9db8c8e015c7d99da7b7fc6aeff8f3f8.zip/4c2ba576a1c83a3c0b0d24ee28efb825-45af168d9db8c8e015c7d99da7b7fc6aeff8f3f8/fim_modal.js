require([
    'underscore',
    'backbone',
    'splunkjs/mvc',
    '../app/<app_name>/components/modalview',
    'splunkjs/mvc/searchmanager',
    'splunkjs/mvc/simplexml/ready!'
], function (_, Backbone, mvc, ModalView, SearchManager) {
    var auditSearch = mvc.Components.get('auditSearch');
    var actionSearch = mvc.Components.get('actionSearch');
    var tokens = mvc.Components.get('submitted');
    var fimStatusSearch = mvc.Components.get('fimStatusSearch');
    var fimAuditSearch = mvc.Components.get('fimAuditSearch');
    var fimStatusTable = mvc.Components.get('fim_status');

    $('.actionBtn').on("click", function (e) {
        e.preventDefault();
        var _title = "Confirm Bulk Action";
        var _message = "Are you sure you want to complete this action? It will remove all current information in the hashtable! This operation will take 1-2 minutes to complete.";
        //pass the value of the item we clicked on to the title variable
        var modal = new ModalView.show({
            title: _title,
            message: _message,
            callback: function (confirmed) {
                if (!confirmed) return; // early return
                tokens.set('perform_action', 'true');
                actionSearch.startSearch();
                auditSearch.startSearch();

                actionSearch.on('search:done', function () {
                    fimStatusSearch.startSearch();
                });

                auditSearch.on('search:done', function () {

                    fimAuditSearch.startSearch();
                });
            }
        });
    });
});