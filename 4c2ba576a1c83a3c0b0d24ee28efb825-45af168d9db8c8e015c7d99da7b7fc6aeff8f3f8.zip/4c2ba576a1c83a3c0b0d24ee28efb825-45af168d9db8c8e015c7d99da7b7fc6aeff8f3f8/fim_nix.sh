WATCHLIST="../default/watchlist.conf"

while read line; do
  echo -n "checksum" && shasum $line
done < $WATCHLIST