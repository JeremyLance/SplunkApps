define([
    'underscore',
    'backbone',
    'jquery'
], function (_, Backbone, $) {
    var modalTemplate = "<div id=\"pivotModal\" class=\"modal\">" +
        "<div class=\"modal-header\"><h3><%- title %></h3><button class=\"dtsBtn close\">Close</button></div>" +
        "<div class=\"modal-body\"><h3><%- message %></h3></div>" +
        "<div class=\"modal-footer\"><button " +
        "class=\"btn-default cancel\">Cancel</button><button " +
        "class=\"btn-primary confirm\">Confirm</button></div>" +
        "</div>" +
        "<div class=\"modal-backdrop\"></div>";

    var ModalView = Backbone.View.extend({

        template: _.template(modalTemplate),
        events: {
            'click .close': 'close',
            'click .cancel': 'close',
            'click .modal-backdrop': 'close',
            'click .confirm': 'confirm',
        },
        initialize: function (options) {
            this.options = _.extend({title: 'Are you sure?', message: 'Please confirm your action'}, options);
        },
        render: function () {
            this.$el.html(this.template(this.options));
            return this;
        },
        show: function () {
            $(document.body).append(this.render().el);
            return this;
        },
        close: function () {
            this.remove();
            var cb = this.options.callback;
            if (cb) cb(false);
        },

        confirm: function () {
            this.remove();
            var cb = this.options.callback;
            if (cb) cb(true);
        }
    }, {
        // Static function
        show: function (options) {
            return new ModalView(options).show();
        }
    });

    return ModalView;
});