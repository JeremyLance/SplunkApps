Splunk Add-on for Microsoft IIS
Copyright (C) 2020 Splunk Inc. All Rights Reserved.

For documentation, see: https://docs.splunk.com/Documentation/AddOns/latest/MSIIS
